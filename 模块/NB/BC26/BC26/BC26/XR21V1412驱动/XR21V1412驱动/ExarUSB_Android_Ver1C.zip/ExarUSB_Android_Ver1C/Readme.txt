November 24, 2015 - Version 1C
===============================

This sample Android Application demonstrates the functionality of Exar's USB UARTs.

Please refer to the user's manual included within this zip file (document version number is 1C).

NOTE:
-----
In order for the application to work correctly the cdc-acm\custom driver module must be disabled/removed.

Technical Support
-----------------
To request the source code for the App or for any technical questions, 
please send an e-mail to uarttechsupport@exar.com. 


Revision History
-----------------
Ver. 1C - November 2015
 - Added support for XR22801, XR22802 and XR22804 device.
 - Fixed bug where only first channel of a multi-channel device was working in some Android versions.
  
Ver. 1B � September 2014
 - Added support for XR21V1412, XR21V1414, XR21B1420, XR21B1422, XR21B1424
 - Added custom baud rate support for XR21V1410, XR21V1412, XR21V1414
 - Added support for selecting the port in a multi-channel device

Beta version � June 2014
 - Initial release with support for XR21V1410 and XR21B1411
